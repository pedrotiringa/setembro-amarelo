criaCartao(
//categoria,
'Progamação'
//pergunta,
'O que é JavaScript'
//resposta,
'O JavaScript é uma linguagem de programação'
)

criaCartao(
    //categoria,
    'Progamação'
    //pergunta,
    'O que é JavaScript'
    //resposta,
    'O JavaScript é uma linguagem de programação'
    )

criaCartao(
        //categoria,
        'Progamação'
        //pergunta,
        'O que é JavaScript'
        //resposta,
        'O JavaScript é uma linguagem de programação'
        )